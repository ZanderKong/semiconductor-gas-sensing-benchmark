
# 审核方法

## MCQ 选项审核

每个选项分别检查：

1. 选项自身在科学上是否成立；
2. 在题干条件下是否回答主问题；
3. 是否只是次优动作，还是事实错误；
4. 是否与 Gold 描述同一机制或互补证据；
5. 是否包含不必要的绝对化语言；
6. 是否构成安全、数据完整性或合规失败；
7. 是否能作为有效干扰项；
8. 外部证据能否支持该选项或排除该选项。

`invalid_distractor_because_defensible` 表示非 Gold 选项仍可合理辩护。它会降低单选题的结构效度，但本轮不改变冻结 Gold。

## Reference Answer 外部证据审核

Reference Answer 被拆分为 112 条独立命题。每条命题分别标记：

- scientific fact or mechanism；
- methodological principle；
- evidence limit；
- experimental design or method；
- safety or normative boundary；
- project decision rule。

外部来源优先级：

1. 官方安全、计量和统计来源；
2. 原始研究与方法学论文；
3. 近期预印本仅用于补充，并明确其局限；
4. 项目自身题库只用于确认原文，不作为独立证据。

## 证据结论

- `externally_supported_with_scope_limits`
- `externally_supported_safety_boundary`
- `supported_with_nonunique_assignment_boundary`
- `partially_supported_needs_direct_phase_evidence`
- `partially_supported_needs_compound_solution_data`
- `normative_project_policy_not_externally_provable`
- `normative_project_acceptance_rule`
- `normative_route_choice_supported_by_feasibility_only`

## 重要限制

本轮为完整的逐选项和逐命题审核，每条记录均有来源映射与证据边界。它不是对每一个材料体系重新实施实验，也不是对全部文献做穷尽式系统综述。样品级因果结论仍需项目实验数据和直接表征。


# Codex Addendum — MCQ Option and Reference Evidence Audit

## Inputs

- `mcq_122_item_option_set_summary.csv`
- `mcq_488_option_audit.csv`
- `mcq_option_issue_queue.csv`
- `fr_30_reference_answer_external_evidence_audit.csv`
- `fr_112_reference_claim_evidence_audit.csv`
- `external_evidence_source_ledger.csv`
- `audit_summary.json`

## Frozen v0.6.0 rules

Do not modify:

- item text;
- option text;
- Gold answers;
- Reference Answers;
- item IDs;
- raw model outputs;
- historical result files.

## Required repository integration

1. Add all audit files under a versioned review directory.
2. State that 122 MCQs and 488 options were individually reviewed.
3. State that 30 Reference Answers were decomposed into 112 claims and externally audited.
4. Publish the count of defensible non-Gold options.
5. Disclose the `SGS-FM-034` Reference rationale error.
6. Distinguish scientific evidence from project-defined gates and redaction policy.
7. Add schema tests:
   - 122 MCQ item summaries;
   - 488 unique `(item_id, option_letter)` rows;
   - exactly four options per MCQ;
   - exactly one current Gold per item;
   - 30 Reference item rows;
   - 112 unique claim IDs;
   - every non-normative claim has either source IDs or an explicit self-contained evidence explanation.
8. Preserve the reviewer identity boundary.
9. Do not recompute scores until the project owner lifts the content freeze.

## Future correction order

1. Correct `SGS-FM-034` Reference rationale.
2. Rewrite option sets containing defensible non-Gold alternatives.
3. Convert suitable mechanism/action questions to multi-select or structured short answer.
4. Tighten CuO–H2S and O 1s Reference evidence boundaries.
5. Label route priorities, go/no-go thresholds and redaction rules as project-defined.
6. Re-score only after a versioned Gold migration and publish old/new diffs.

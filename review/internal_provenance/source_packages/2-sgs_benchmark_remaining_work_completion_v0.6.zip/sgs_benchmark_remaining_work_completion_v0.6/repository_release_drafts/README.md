
# Semiconductor Gas Sensing Benchmark

SGS152 evaluates scientific reasoning in semiconductor gas-sensing research across multiple-choice and free-response tasks. Version 0.6.0 publishes a reviewed scoring policy, corrected Hard Fail interpretation, full content-audit records and clearer boundaries for diagnostic subsets.

## Version 0.6.0 scope

- 152 main-set items;
- 122 MCQs and 30 free-response tasks;
- 40 optional robustness variants;
- 50 Hard50 regression-diagnostic items;
- four evaluated model systems.

## Audit status

- all 242 main and diagnostic items have item-level validity records;
- all 488 MCQ options have option-level audit records;
- 30 Reference Answers have been decomposed into 112 evidence claims;
- 120 free-response answers have model-assisted secondary adjudication;
- 960 dimension-level scores have been produced;
- 15 historical Hard Fails were reclassified to 3 confirmed failures and 12 ordinary scoring defects;
- DeepSeek SGS-081 remains a missing answer scored 0.

## Interpretation limits

The review is an expert-style model-assisted audit under project-owner supervision. It is not an independent external human blind review. The robustness and Hard50 sets are diagnostic supplements. Hard50 is saturated and must not be presented as a discriminative hard leaderboard.

Known wrong or ambiguous items remain frozen for historical reproducibility and are disclosed in the audit package.

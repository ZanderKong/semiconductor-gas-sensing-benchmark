
# Reproducibility

## Frozen inputs

- Repository commit: `dfa28407e5130dbc4328ac006a5368f18bdbff7d`
- Raw evidence archive: `artifacts/SGS152_raw_evidence_20260713.zip`
- Archive GitHub blob SHA: `90b889723371fcf604541151f2c0b2700581ec43`

## Required rebuild

Run the supplied deterministic reconstruction script locally. The release is complete only when:

- raw outputs rebuild all parsed files;
- stable-key row counts and fields match;
- archive and file hashes are recorded;
- the dirty-tree flag is explained using actual Git state;
- all differences are published.

The model-assisted review environment verified the archive inventory but did not complete byte-level reconstruction because the connector did not expose the complete binary archive to the execution runtime.

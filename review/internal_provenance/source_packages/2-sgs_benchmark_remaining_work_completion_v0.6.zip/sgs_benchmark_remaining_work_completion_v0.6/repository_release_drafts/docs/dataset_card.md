
# Dataset Card — SGS152 v0.6.0

## Intended use

SGS152 diagnoses professional scientific reasoning in semiconductor gas-sensing R&D. It covers literature interpretation, mechanism boundaries, experimental design, data quality, process scale-up, safety and route selection.

## Composition

- Main set: 152 items
- MCQ: 122
- Free response: 30
- Robustness: 40 variants
- Hard50: 50 regression items

## Review coverage

Every item has an item-validity record. Every MCQ option has a separate audit. Reference Answers are linked to claim-level evidence records. Free-response outputs have eight-dimensional secondary adjudication.

## Known limitations

- 56 non-Gold MCQ options remain defensible, complementary or overlapping.
- Five P0 content defects were identified across the full 242-item inventory.
- Two robustness variants contain wrong Gold/reference logic.
- Two Hard50 items contain wrong Gold/reference logic.
- Hard50 performance is saturated at 47–48/50.
- Some engineering gates and redaction rules are project-defined norms rather than externally provable scientific facts.
- CuO–H₂S phase-conversion attribution and one paper-loading root-cause claim need more direct evidence.
- Independent blinded human review has not yet been completed.

## Responsible use

Do not use the benchmark as a safety authorization system or as a substitute for laboratory SOPs, trained personnel, institutional approval or engineering controls.

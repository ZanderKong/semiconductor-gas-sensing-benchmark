
# Scoring Protocol v0.6.0

## MCQ

MCQ scores use the frozen Gold answers for historical reproducibility. Public interpretation must account for the option-level audit, especially items with defensible non-Gold alternatives or known Gold errors.

## Free response

Each response receives eight dimensions totaling 10 points:

1. professional accuracy;
2. contextual fit;
3. evidence grounding;
4. reasoning path;
5. experimental design;
6. decision logic;
7. safety/privacy;
8. clarity and traceability.

Risk Gates are evaluated before dimension scoring. Ordinary omissions and weak reasoning reduce dimension scores and do not automatically force a zero.

## Missing answers

A missing answer receives 0. DeepSeek SGS-081 remains 0 with no rescue.

## Official v0.6 reviewed averages

- GPT-5.5: 8.213
- Seed-2.1: 7.545
- DeepSeek V4 Pro: 6.732
- MiMo v2.5 Pro: 4.952

These values are model-assisted secondary adjudication results, not independent blind-review scores.

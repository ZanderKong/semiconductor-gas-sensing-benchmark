
# SGS152 v0.6.0 Release Notes

Version 0.6.0 focuses on evaluation reliability and auditability. The release adds full item, option and Reference Answer evidence reviews; replaces over-broad Hard Fail labeling with a narrow risk policy; and publishes model-assisted secondary adjudication for all free-response answers.

The MCQ main set remains highly saturated. Robustness remains optional. Hard50 is retained as a regression diagnostic.

Five frozen content defects and 56 defensible non-Gold MCQ options are publicly disclosed. A separate independent blind human review and local byte-level raw reconstruction remain required before stronger validation claims are made.

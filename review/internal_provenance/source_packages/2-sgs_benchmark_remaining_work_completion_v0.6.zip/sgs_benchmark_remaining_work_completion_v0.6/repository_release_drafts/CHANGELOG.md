
# Changelog

## 0.6.0

### Added

- eight-dimensional free-response adjudication;
- revised Risk Gate and Hard Fail policy;
- complete 242-item validity audit;
- complete 488-option MCQ audit;
- 112-claim external-evidence ledger;
- robustness pair review;
- Hard50 item calibration;
- deterministic raw-rebuild and statistics scripts;
- independent blind-review execution packet.

### Changed

- official reviewed free-response scores;
- interpretation of 12 historical Hard Fails as dimension-level defects;
- Hard50 positioning from hard leaderboard to regression diagnostic.

### Fixed in policy

- DeepSeek SGS-081 remains 0 as a missing answer.
- Hard Fail requires a direct risk/data/privacy/fabrication/derailment failure.

### Known frozen content defects

- SGS-FM-034 reference rationale;
- SGS-007-R03;
- SGS-097-R03;
- SGS-HARD-016;
- SGS-HARD-028.

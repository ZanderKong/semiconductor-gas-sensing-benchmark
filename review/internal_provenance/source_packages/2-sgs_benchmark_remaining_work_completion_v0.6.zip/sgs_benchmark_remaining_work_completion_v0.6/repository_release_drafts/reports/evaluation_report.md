
# Evaluation Report v0.6.0

## Main results

The main MCQ set is highly saturated: the four systems score between 115 and 119 of 122. Small rank differences therefore depend on very few items and are sensitive to ambiguous Gold definitions.

The reviewed free-response scores provide greater separation:

| Model | Reviewed average |
|---|---:|
| GPT-5.5 | 8.213 |
| Seed-2.1 | 7.545 |
| DeepSeek V4 Pro | 6.732 |
| MiMo v2.5 Pro | 4.952 |

## Diagnostic sets

- Robustness: 29–34 of 40, moderate spread, but two P0 variants and nine P1 variants limit interpretation.
- Hard50: 47–48 of 50, very high saturation. Use as regression diagnostic only.

## Review identity

Results are based on model-assisted secondary adjudication supervised by the project owner. Independent blind human scoring remains a separate future validation step.

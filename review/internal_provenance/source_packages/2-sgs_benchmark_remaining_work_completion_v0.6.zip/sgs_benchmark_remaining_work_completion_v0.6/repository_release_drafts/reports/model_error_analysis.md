
# Model Error Analysis

## Cross-model failure families

- evidence overclaim from XPS, EPR or response peaks;
- missing controls and confounded experimental designs;
- failure to separate humidity, chamber, flow and material effects;
- metric over-optimization;
- weak go/no-go logic;
- safety-gate omissions;
- data-integrity mistakes around outliers;
- direct transfer of literature performance into product scenarios.

## Model-level pattern

GPT-5.5 produced the strongest average and no confirmed Hard Fail. Seed-2.1 was generally strong but previously accumulated several over-broad Hard Fail labels. DeepSeek V4 Pro had one missing response and weaker actionability in several tasks. MiMo had the lowest reviewed average and all three confirmed risk-gate failures.

These are benchmark-specific findings and should not be generalized into universal model rankings.

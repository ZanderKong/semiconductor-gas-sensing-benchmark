#!/usr/bin/env python3
"""Strict raw-to-derived reconstruction and byte/row diff harness.

This wrapper calls the full-statistics builder, then compares reconstructed
CSV rows against repository-derived files by stable keys. It deliberately
fails closed on duplicate keys, row-count differences or field differences.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, subprocess, sys
from pathlib import Path

def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def index(rows, keys):
    out = {}
    for r in rows:
        k = tuple(r[x] for x in keys)
        if k in out:
            raise RuntimeError(f"Duplicate key {k}")
        out[k] = r
    return out

def diff_csv(expected, rebuilt, keys):
    a, b = index(read_csv(expected), keys), index(read_csv(rebuilt), keys)
    diffs = []
    for key in sorted(set(a) | set(b)):
        if key not in a:
            diffs.append({"key": key, "type": "extra_rebuilt"})
        elif key not in b:
            diffs.append({"key": key, "type": "missing_rebuilt"})
        elif a[key] != b[key]:
            fields = sorted(k for k in set(a[key]) | set(b[key]) if a[key].get(k) != b[key].get(k))
            diffs.append({"key": key, "type": "field_difference", "fields": fields})
    return diffs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root", type=Path, required=True)
    ap.add_argument("--archive", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    cmd = [
        sys.executable,
        str(Path(__file__).with_name("rebuild_and_compute_full_statistics.py")),
        "--archive", str(args.archive),
        "--repo-root", str(args.repo_root),
        "--out", str(args.out / "statistics"),
    ]
    subprocess.run(cmd, check=True)

    # Extend this mapping only with deterministic parser outputs.
    comparisons = [
        # (expected repository file, rebuilt file, stable keys)
        # Example:
        # (args.repo_root/"results/.../model_outputs.csv",
        #  args.out/"rebuilt/.../model_outputs.csv",
        #  ["id","model_id"]),
    ]
    report = {"comparisons": [], "status": "passed"}
    for expected, rebuilt, keys in comparisons:
        diffs = diff_csv(expected, rebuilt, keys)
        report["comparisons"].append({
            "expected": str(expected),
            "rebuilt": str(rebuilt),
            "keys": keys,
            "diff_count": len(diffs),
            "diffs": diffs[:100],
        })
        if diffs:
            report["status"] = "failed"
    (args.out / "raw_rebuild_diff_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    if report["status"] != "passed":
        raise SystemExit(1)

if __name__ == "__main__":
    main()

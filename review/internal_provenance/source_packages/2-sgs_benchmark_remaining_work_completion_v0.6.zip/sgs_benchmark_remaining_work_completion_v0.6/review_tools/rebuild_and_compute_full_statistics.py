#!/usr/bin/env python3
"""Deterministically rebuild parsed evidence and compute full item-level statistics.

Run from the repository root:
    python review_tools/rebuild_and_compute_full_statistics.py \
      --archive artifacts/SGS152_raw_evidence_20260713.zip \
      --repo-root . \
      --out review_outputs/full_statistics

The script never changes benchmark content or historical results.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, random, shutil, statistics, tempfile, zipfile
from collections import Counter, defaultdict
from pathlib import Path

MODELS = ["gpt-5.5", "deepseek-v4-pro", "mimo-v2.5-pro", "ep-20260703090429-qpmt7"]

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_csv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def write_csv(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0]) if rows else ["empty"]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        if rows: w.writerows(rows)

def rank_desc(scores):
    ordered = sorted(scores, key=lambda m: (-scores[m], m))
    return {m: i + 1 for i, m in enumerate(ordered)}

def bootstrap_ranks(item_correct, iterations=20000, seed=20260713):
    rng = random.Random(seed)
    ids = sorted({iid for (iid, _) in item_correct})
    rank_counts = {m: Counter() for m in MODELS}
    score_samples = {m: [] for m in MODELS}
    for _ in range(iterations):
        sample = [rng.choice(ids) for _ in ids]
        scores = {m: sum(item_correct.get((iid, m), 0) for iid in sample) / len(sample) for m in MODELS}
        ranks = rank_desc(scores)
        for m in MODELS:
            rank_counts[m][ranks[m]] += 1
            score_samples[m].append(scores[m])
    rows = []
    for m in MODELS:
        vals = sorted(score_samples[m])
        lo = vals[int(0.025 * len(vals))]
        hi = vals[int(0.975 * len(vals))]
        row = {"model_id": m, "score_ci_low": lo, "score_ci_high": hi}
        for rank in range(1, len(MODELS)+1):
            row[f"rank_{rank}_probability"] = rank_counts[m][rank] / iterations
        rows.append(row)
    return rows

def process_set(name, model_csv, gold_map, metadata, out):
    rows = read_csv(model_csv)
    item_correct, answers = {}, {}
    for r in rows:
        key = (r["id"], r["model_id"])
        ans = (r.get("answer") or "").strip().upper()
        answers[key] = ans
        item_correct[key] = int(ans == gold_map.get(r["id"], ""))
    item_rows = []
    for iid in sorted(gold_map):
        model_answers = [answers.get((iid, m), "") for m in MODELS]
        correct = [item_correct.get((iid, m), 0) for m in MODELS]
        counts = Counter(model_answers)
        entropy = 0.0
        for n in counts.values():
            p = n / len(MODELS)
            if p: entropy -= p * math.log2(p)
        item_rows.append({
            "set": name,
            "item_id": iid,
            "gold": gold_map[iid],
            "correct_count": sum(correct),
            "proportion_correct": sum(correct)/len(MODELS),
            "answer_entropy_bits": entropy,
            "distinct_answers": len(counts),
            **{f"{m}_answer": answers.get((iid,m),"") for m in MODELS},
            **{f"{m}_correct": item_correct.get((iid,m),0) for m in MODELS},
            "domain": metadata.get(iid, {}).get("domain", ""),
            "stage": metadata.get(iid, {}).get("scenario_stage", ""),
            "failure_mode": metadata.get(iid, {}).get("failure_mode", ""),
            "source": metadata.get(iid, {}).get("source", ""),
            "consistency_group_id": metadata.get(iid, {}).get("consistency_group_id", ""),
        })
    write_csv(out / f"{name}_item_difficulty.csv", item_rows)

    disagreement = []
    for i, a in enumerate(MODELS):
        for b in MODELS[i+1:]:
            common = sorted(gold_map)
            answer_dis = sum(answers.get((x,a)) != answers.get((x,b)) for x in common)/len(common)
            correctness_dis = sum(item_correct.get((x,a)) != item_correct.get((x,b)) for x in common)/len(common)
            disagreement.append({
                "set": name, "model_a": a, "model_b": b,
                "answer_disagreement_rate": answer_dis,
                "correctness_disagreement_rate": correctness_dis,
            })
    write_csv(out / f"{name}_model_disagreement.csv", disagreement)

    totals = {m: sum(item_correct.get((iid,m),0) for iid in gold_map) for m in MODELS}
    base_ranks = rank_desc(totals)
    loo = []
    for iid in sorted(gold_map):
        scores = {m: totals[m] - item_correct.get((iid,m),0) for m in MODELS}
        ranks = rank_desc(scores)
        loo.append({
            "set": name, "deleted_item_id": iid,
            **{f"{m}_score": scores[m] for m in MODELS},
            **{f"{m}_rank": ranks[m] for m in MODELS},
            "rank_changed": any(ranks[m] != base_ranks[m] for m in MODELS),
        })
    write_csv(out / f"{name}_leave_one_item_out_ranks.csv", loo)
    write_csv(out / f"{name}_bootstrap_rank_stability.csv", bootstrap_ranks(item_correct))
    return item_rows, item_correct

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--archive", required=True, type=Path)
    ap.add_argument("--repo-root", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    if not args.archive.exists():
        raise SystemExit(f"Archive missing: {args.archive}")
    before_hash = sha256(args.archive)
    with tempfile.TemporaryDirectory() as td:
        extract = Path(td)
        with zipfile.ZipFile(args.archive) as z:
            bad = z.testzip()
            if bad: raise SystemExit(f"Bad ZIP member: {bad}")
            z.extractall(extract)

        benchmark = json.loads((args.repo_root / "data/benchmark.json").read_text(encoding="utf-8"))
        metadata = {x["id"]: x for x in benchmark}
        gold_all = {x["id"]: x.get("answer","") for x in benchmark if x.get("question_type") == "multiple_choice"}

        paths = {
            "main": extract / "results/standard_20260703/sgs152_mcq/model_outputs.csv",
            "robustness": extract / "results/standard_20260703/robustness/model_outputs.csv",
            "hard50": extract / "results/standard_20260703/hard50/model_outputs.csv",
        }
        for p in paths.values():
            if not p.exists(): raise SystemExit(f"Missing extracted file: {p}")

        set_items = {
            "main": {k:v for k,v in gold_all.items() if not "-R" in k and not k.startswith("SGS-HARD-")},
            "robustness": {k:v for k,v in gold_all.items() if "-R" in k},
            "hard50": {k:v for k,v in gold_all.items() if k.startswith("SGS-HARD-")},
        }

        all_item_rows = {}
        all_correct = {}
        for name in ["main","robustness","hard50"]:
            item_rows, correct = process_set(name, paths[name], set_items[name], metadata, args.out)
            all_item_rows[name] = item_rows
            all_correct[name] = correct

        # Group/source-weighted model scores
        weighted_rows = []
        for name, item_rows in all_item_rows.items():
            group_members = defaultdict(list)
            for row in item_rows:
                group = row["consistency_group_id"] or row["source"] or row["item_id"]
                group_members[group].append(row["item_id"])
            for m in MODELS:
                vals = []
                for group, ids in group_members.items():
                    vals.append(sum(all_correct[name].get((iid,m),0) for iid in ids)/len(ids))
                weighted_rows.append({
                    "set": name, "model_id": m,
                    "group_weighted_accuracy": sum(vals)/len(vals),
                    "effective_groups": len(vals),
                })
        write_csv(args.out / "group_weighted_model_scores.csv", weighted_rows)

        # Deterministic raw-to-derived checks
        checks = []
        for name, p in paths.items():
            checks.append({
                "artifact": name,
                "path": str(p.relative_to(extract)),
                "sha256": sha256(p),
                "rows": len(read_csv(p)),
            })
        (args.out / "raw_rebuild_checks.json").write_text(
            json.dumps({
                "archive_sha256_before": before_hash,
                "archive_sha256_after": sha256(args.archive),
                "archive_unchanged": before_hash == sha256(args.archive),
                "artifacts": checks,
            }, indent=2), encoding="utf-8"
        )

if __name__ == "__main__":
    main()

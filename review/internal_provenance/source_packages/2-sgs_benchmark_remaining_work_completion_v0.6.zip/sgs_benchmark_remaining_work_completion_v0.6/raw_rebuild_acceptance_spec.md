
# 原始证据确定性重建验收规范

## 已核对

- 冻结归档路径：`artifacts/SGS152_raw_evidence_20260713.zip`
- GitHub blob SHA：`90b889723371fcf604541151f2c0b2700581ec43`
- 归档库存包含主集 MCQ、开放题、Judge、Robustness、Hard50 的四模型原始输出和阶段 manifest。
- 冻结仓库提交：`dfa28407e5130dbc4328ac006a5368f18bdbff7d`

## 当前环境尚未执行的部分

当前连接器只能分段显示二进制 Base64，不能把完整 ZIP 落入 Python 运行时。因此以下结果不能声称已经完成：

- 完整解压；
- 原始文本到 CSV 的确定性重建；
- 逐行 diff；
- 归档内所有文件 SHA-256 核对；
- `artifact_generation_working_tree_dirty=true` 根因确认。

## 本地执行

```bash
python review_tools/rebuild_raw_evidence.py   --repo-root .   --archive artifacts/SGS152_raw_evidence_20260713.zip   --out review_outputs/raw_rebuild
```

## 必须通过的断言

1. ZIP `testzip()` 返回空；
2. 归档执行前后 SHA-256 不变；
3. 主集 MCQ 输出为 122×4；
4. Robustness 输出为 40×4；
5. Hard50 输出为 50×4；
6. 开放题输出为 30×4，DeepSeek SGS-081 仍为空；
7. Judge 输出为 120 条且无重复 `(task_id, model_id)`；
8. 每个派生文件按稳定主键逐字段相等；
9. 所有不一致写入机器可读 diff；
10. dirty-tree 标志必须绑定实际 `git status --porcelain` 和生成脚本提交状态，不得凭 manifest 猜测。


# 剩余工作补完报告

## 已在本轮补齐

1. Robustness 40 道逐题、逐组裁决；
2. Hard50 50 道逐题校准与去留/重写方案；
3. 全部现有审核结果的统计汇总；
4. item-level 完整统计、bootstrap、leave-one-out 和相关性计算脚本；
5. 真正独立盲审的匿名化构建脚本、评分模板和解盲规则；
6. 原始证据确定性重建脚本和验收断言；
7. README、Dataset Card、Scoring Protocol、Risk Gates、Reproducibility、Evaluation Report、Model Error Analysis、Final Release Audit、Changelog 和 Release Notes 正文草案。

## 当前准确完成状态

| 部分 | 状态 |
|---|---|
| 152 主集逐题有效性 | 完成 |
| 122 MCQ / 488 选项 | 完成 |
| 30 Reference Answer / 112 命题 | 完成，证据缺口已显式记录 |
| 120 回答与 960 维度分数 | 完成 |
| Robustness 40 | 完成 |
| Hard50 50 | 完成 |
| 最终发布正文 | 完成草案 |
| 真正独立盲审 | 需要另一位未被污染的评审者执行 |
| 原始归档 byte-level 重建 | 需要 Codex/本地环境运行已提供脚本 |
| 完整 item-level bootstrap 数值 | 已提供脚本，依赖同一次本地原始归档运行 |

## Robustness 结果

- P0：2
- P1：9
- P2：14
- P3：15

`SGS-007-R03` 与 `SGS-097-R03` 不应继续计入一致性分数，除非先修复 Gold/variant。

## Hard50 结果

- 47 题可保留为 regression diagnostic；
- 1 题需重写；
- 2 题在修复 Gold/Reference 前应停用；
- 全部 50 题若要重新组成真正 Hard leaderboard，都需要增强信息密度和去除明显线索。

## 仍不能声称的内容

- 独立外部人类专家盲审已经完成；
- 已经从原始 ZIP 重建所有派生文件并逐字节一致；
- 已经得到基于原始 item-level 数据的 bootstrap 排名概率。

这三项中的后两项已经转化为可直接运行的本地脚本；第一项已经转化为可直接交给独立评审者的执行包。

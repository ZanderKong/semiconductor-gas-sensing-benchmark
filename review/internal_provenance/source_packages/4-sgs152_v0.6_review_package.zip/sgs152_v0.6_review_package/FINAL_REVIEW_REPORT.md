# SGS152 v0.6.0 Review Package — Final Report

## Completed work

- Froze the v0.6.0 scope and project-owner decisions.
- Defined a Hard Fail policy where only confirmed safety, data-integrity, privacy, fabrication, or no-valid-answer failures zero the official item score.
- Audited all 30 free-response item designs at the policy and rubric-interpretation level.
- Produced second-pass eight-dimension adjudication for all 120 answers.
- Reclassified 15 previous Hard Fails into 3 confirmed and 12 ordinary dimension issues.
- Kept DeepSeek `SGS-081` at deterministic no-rescue zero.
- Computed Judge reliability metrics and disagreement cases.
- Preserved all 122 MCQ items and Gold Answers and produced structural validation plus a claim-level fact-review queue.
- Reviewed the role and saturation of Robustness and Hard50.
- Produced evidence, provenance, schema, validation and Codex integration artifacts.
- Created a consolidated Excel review dashboard.

## v0.6.0 free-response results

| Model | Reviewed average | Official average | Confirmed Hard Fails | No answers |
|---|---:|---:|---:|---:|
| GPT-5.5 | 8.213 | 8.213 | 0 | 0 |
| Seed-2.1 | 7.545 | 7.545 | 0 | 0 |
| DeepSeek V4 Pro | 6.732 | 6.732 | 0 | 1 |
| MiMo v2.5 Pro | 5.257 | 4.952 | 3 | 0 |

## Hard Fail reclassification

- Previous Hard Fails: 15
- Confirmed for v0.6.0: 3
- Downgraded to ordinary dimension issues: 12

Confirmed cases:

1. MiMo `SGS-082` — data integrity;
2. MiMo `SGS-FM-FR-007` — safety;
3. MiMo `SGS-FM-FR-011` — data integrity.

## Release blocker

The remaining P0 technical blocker is deterministic replay of
`artifacts/SGS152_raw_evidence_20260713.zip` in a clean local worktree.

The current connector verified archive presence, groups and manifests but could
not mount and extract the binary ZIP into the Python environment. Codex must
complete the prescribed unzip, rebuild, hash and row-diff process.

## Review identity

This package is a model-assisted expert-style adjudication under project-owner
supervision. It is not an independent external human blind review.

## MCQ boundary

All 122 MCQ items are frozen and retained. This package completed inventory,
policy, structural assertions and a factual-review queue. It does not claim
that every MCQ claim and distractor has been externally verified against
primary literature.

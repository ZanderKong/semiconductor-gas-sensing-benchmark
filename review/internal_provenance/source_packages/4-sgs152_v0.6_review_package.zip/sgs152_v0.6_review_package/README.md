
# SGS152 v0.6.0 Review Package

这是一套供 Codex 最终整合的冻结评审包。

## 最重要的变化

- 目标版本改为 v0.6.0；
- 题目、选项和 Gold Answer 不修改、不删除；
- confirmed Hard Fail 官方条目分归零；
- 现有 15 个 Hard Fail 重分类为 3 个 confirmed、12 个普通重大缺陷；
- 120 条回答均有八维第二轮 adjudication；
- 新增 Judge 可靠性、证据台账、诊断集定位和 Codex 回写规范；
- 原始 ZIP 的本地 deterministic replay 仍是正式发布前的 P0 阻断项。

## 阅读顺序

1. `00_review_foundation/owner_decisions.json`
2. `00_review_foundation/scoring_policy_v0.6.0.md`
3. `01_free_response_design_review/hard_fail_reclassification.csv`
4. `02_full_response_adjudication/official_free_response_summary.csv`
5. `03_judge_reliability/judge_reliability_report.md`
6. `00_review_foundation/provenance_open_issues.csv`
7. `08_codex_handoff/codex_execution_prompt.md`

## 身份边界

本包使用专家学术审稿式标准，但执行者是 AI 模型。正确表述是：

`model-assisted expert-style adjudication under project-owner supervision`

禁止表述为独立外部人类专家盲审。

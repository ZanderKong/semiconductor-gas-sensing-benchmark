
# Codex Final Integration Prompt — SGS152 v0.6.0

You are integrating a frozen review package into
`ZanderKong/semiconductor-gas-sensing-benchmark`.

## Source of truth

Use only the files in `sgs152_v0.6_review_package`.
Do not make new scientific judgments.
Do not rerun participating models.
Do not repair or rescue missing answers.
Do not change or delete benchmark items, options, Gold Answers, or IDs.

## Frozen project-owner decisions

1. Release target: `v0.6.0`.
2. Confirmed Hard Fail affects score: official item score is `0`.
3. Provisional Judge Hard Fail does not affect score until confirmed.
4. No-answer uses deterministic no-rescue zero.
5. v0.5.0 remains a historical baseline.
6. This is model-assisted project-owner adjudication, not independent external human blind review.

## Required execution order

### Phase 1 — Evidence replay

Follow `08_codex_handoff/codex_local_raw_archive_verification.md`.

Stop release integration if:
- files are missing;
- parsed outputs cannot be rebuilt;
- hashes or rows differ without an explained deterministic transformation.

Do not stop all work for minor documentation differences; record them.

### Phase 2 — Create v0.6 review result directory

Create a new versioned directory. Do not overwrite v0.5.0 files.

Copy and validate:
- `full_review_by_item.csv`
- `full_review_by_dimension.csv`
- `confirmed_hard_fails.csv`
- `score_overrides.csv`
- `official_free_response_summary.csv`

### Phase 3 — Recompute

From `full_review_by_item.csv`, recompute:
- model reviewed average before Hard Fail;
- official average after Hard Fail;
- hard-fail count;
- no-answer count;
- dimension averages;
- task and domain summaries when metadata permits.

Never manually type summary numbers.

### Phase 4 — Policy and documentation

Update the files listed in `release_file_update_plan.md`.

Correct the stale MCQ input path in `docs/scoring_protocol.md`.

Explain:
- v0.5.0 Hard Fails were count-only;
- v0.6.0 confirmed Hard Fails zero the official item score;
- ordinary missing controls/formulas/matrices are dimension deductions;
- 12 old labels were downgraded;
- 3 were confirmed.

### Phase 5 — Judge reliability

Publish the supplied Judge reliability report and metrics.
Do not claim an independent blind-review agreement estimate.

### Phase 6 — MCQ and diagnostics

Keep all MCQ items and Gold Answers unchanged.
Keep MCQ as the only main leaderboard.
Label Robustness as optional diagnostics.
Label Hard50 as saturated regression diagnostics.

### Phase 7 — Validation

Implement every assertion in:
- `00_review_foundation/audit_assertions.json`
- `00_review_foundation/final_validation_spec.md`

Add CI that runs:
- data validation;
- schema validation;
- score recomputation;
- public provenance audit;
- raw archive audit when archive is available;
- generated-file diff check.

## Required final report

Produce:
- exact commands run;
- files added and modified;
- old vs new free-response summaries;
- confirmed and downgraded Hard Fail list;
- raw archive replay result;
- tests and audit results;
- unresolved issues;
- final commit SHA.

Do not silently resolve scientific disagreements or edit review rationales.

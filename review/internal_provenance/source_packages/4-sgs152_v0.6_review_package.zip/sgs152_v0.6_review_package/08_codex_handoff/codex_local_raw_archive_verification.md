
# Codex Local Raw Archive Verification

1. Checkout commit `dfa28407e5130dbc4328ac006a5368f18bdbff7d`.
2. Create an isolated clean worktree.
3. Extract `artifacts/SGS152_raw_evidence_20260713.zip` into a temporary directory outside tracked paths.
4. Record archive SHA-256 and every member path, size and SHA-256.
5. Confirm expected raw groups:
   - 4 SGS152 MCQ model outputs;
   - 4 SGS152 free-response model outputs;
   - 4 robustness outputs;
   - 4 Hard50 outputs;
   - 4 Judge outputs;
   - stage and smoke manifests.
6. Rebuild parsed model output CSVs using the repository parser at the frozen code commit.
7. Rebuild Judge by-item, by-dimension and summary from raw Judge text.
8. Compare rebuilt artifacts with committed files using:
   - SHA-256;
   - row counts;
   - primary keys;
   - sorted row-by-row diff.
9. Investigate `artifact_generation_working_tree_dirty=true`.
10. Produce:
   - `raw_archive_verification_manifest.json`;
   - `raw_to_derived_diff.csv`;
   - `raw_archive_verification_report.md`.
11. Do not alter model answers, retry failed generations or rescue missing answers.


# v0.6.0 Release File Update Plan

## Must update

- README.md
- docs/dataset_card.md
- docs/scoring_protocol.md
- docs/risk_gates.md
- docs/reproducibility.md
- reports/evaluation_report.md
- reports/model_error_analysis.md
- reports/final_release_audit.md
- CHANGELOG.md
- RELEASE_NOTES.md

## Must add

- reports/judge_reliability_report.md
- results/.../free_response_review_v0_6/full_review_by_item.csv
- results/.../free_response_review_v0_6/full_review_by_dimension.csv
- results/.../free_response_review_v0_6/confirmed_hard_fails.csv
- results/.../free_response_review_v0_6/official_free_response_summary.csv
- review/provenance/raw_archive_verification_manifest.json
- review/evidence/claim_evidence_ledger.csv

## Must preserve

- v0.5.0 Judge outputs;
- prior delegated adjudication;
- raw evidence archive;
- old summaries as historical evidence;
- main MCQ task content and Gold Answers.

## Required wording

- `v0.6.0`
- `model-assisted project-owner adjudication`
- `confirmed Hard Fail receives official item score 0`
- `MCQ remains the only main leaderboard`
- `Hard50 is saturated and diagnostic only`
- `not an independent external human blind review`

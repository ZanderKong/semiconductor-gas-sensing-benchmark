
# v0.6.0 Full-response Adjudication Notes

## 覆盖

- 30 道题；
- 4 个候选模型；
- 120 条回答；
- 960 个维度评分记录。

## 评分口径

本轮是基于现有 Judge、项目负责人委托复核、外部证据核验和 v0.6.0 新政策完成的第二轮 adjudication。它不是首次独立盲审。

八维评分保留回答的有效内容；confirmed Hard Fail 通过 `official_item_score=0` 影响官方汇总。

## Hard Fail 结果

- v0.5.0 当前 Hard Fail：15
- v0.6.0 确认：3
- 降级为普通重大缺陷：12
- 缺答：1

确认条目：

1. MiMo `SGS-082`：数据完整性；
2. MiMo `SGS-FM-FR-007`：安全；
3. MiMo `SGS-FM-FR-011`：数据完整性。

## 重要解释

- 公式、单位、矩阵或对照缺失会降低普通维度分，但不自动归零。
- 异常值无法证明错误时，仅因影响统计而删除，属于数据完整性风险。
- 酸与 Fe/Al 接触的放氢风险被遗漏后仍给出执行建议，属于安全风险。
- DeepSeek `SGS-081` 保持 no-rescue 0 分，单独标记为 no-answer。

## 使用限制

维度分是 post-hoc secondary adjudication，适合用于 v0.6.0 项目负责人裁决和 Judge 可靠性分析。发布时必须保留身份边界声明。

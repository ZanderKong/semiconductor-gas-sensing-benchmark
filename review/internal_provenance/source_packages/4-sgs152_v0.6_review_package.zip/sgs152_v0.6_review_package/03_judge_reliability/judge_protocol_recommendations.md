
# Judge Protocol Recommendations for v0.6.0

1. Judge 先给八维分，再独立输出 risk-gate JSON。
2. 每个 Hard Fail 必须包含：
   - category；
   - exact answer evidence；
   - exact policy trigger；
   - why ordinary deduction is insufficient；
   - confidence。
3. 自动 Judge 的 gate 状态只能是 provisional。
4. 所有 provisional Hard Fail 必须由第二评审确认。
5. 对涉及参评 GPT 模型的样本进行身份盲化。
6. 评分 Prompt 中明确：公式、对照、矩阵和 go/no-go 缺失属于普通扣分。
7. 对安全与数据完整性使用行为型触发条件，避免用“没提安全”直接判 Hard Fail。
8. 保存原始 Judge 输出、解析结果、Prompt Hash、任务 Hash 和代码 Commit。
9. 每次发布报告 hard-fail precision、复核覆盖率和 unresolved 数量。
10. 至少抽查所有高分、低分、Hard Fail、缺答和模型间分歧最大的样本。


# Blind Review Rules

理想流程应在模型身份和旧分数隐藏时完成首次判断。本轮已接触 v0.5.0 Judge 和 adjudication，因此准确名称为：

`post-hoc evidence-assisted secondary adjudication`

它不能被描述为独立盲审。

后续真正的盲审包应：

1. 为每个模型随机分配 candidate ID；
2. 去除 model_id、provider、旧总分、旧维度分和 Judge 评论；
3. 随机化同题四个回答顺序；
4. 先完成八维评分和 Hard Fail 判断；
5. 冻结后再揭示身份并做差异分析；
6. 保留盲审文件 Hash，防止事后替换。

本包中的 candidate ID 可用于展示，但不能反向宣称本轮过程从未见过真实身份。

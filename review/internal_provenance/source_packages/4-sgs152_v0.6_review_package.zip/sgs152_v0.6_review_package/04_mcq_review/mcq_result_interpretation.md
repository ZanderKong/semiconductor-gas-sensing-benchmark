
# MCQ Result Interpretation for v0.6.0

冻结主榜：

| Model | Correct / 122 | Accuracy |
|---|---:|---:|
| MiMo v2.5 Pro | 119 | 97.54% |
| Seed-2.1 | 118 | 96.72% |
| GPT-5.5 | 117 | 95.90% |
| DeepSeek V4 Pro | 115 | 94.26% |

解释：

- 差距只有 4 题，单题设计和解析错误可能显著影响排序；
- 本轮不修改 Gold 或题目，保持与 v0.5.0 可比；
- v0.6.0 报告应明确主榜已接近饱和；
- 领域、failure mode 和错误选项 profile 比单一总分更有诊断价值；
- 在完成逐题事实与选项审查前，不应把细小准确率差距解释为稳定能力差距。


# MCQ Option Review Protocol

每道题后续应对 Gold 和每个 distractor 分别记录：

- option text；
- scientifically possible；
- contextually appropriate；
- hidden assumption；
- option profile correctness；
- rationale correctness；
- source support；
- ambiguity severity；
- recommended future action。

判定规则：

1. “存在条件下可行”不等于当前上下文最佳。
2. 只有优先级差异的选项，应确保题干明确问“最优先”或“最稳妥”。
3. 安全选项不能仅凭语气天然显得正确。
4. Gold 不应系统性成为最长、最完整或唯一含“验证”的选项。
5. distractor rationale 应说明其在哪些条件下成立、为何当前不优先。
6. synthetic scientific-stress 题应避免只测试基础记忆或明显排除法。

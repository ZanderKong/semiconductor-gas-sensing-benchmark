
# Coverage and Interpretation Limits

## 覆盖

- 主集 MCQ：122；
- 主集开放题：30；
- 开放题回答：120；
- Robustness：40；
- Hard50：50；
- 领域包括有机、材料、物化、安全、数据分析和研发决策等。

## 统计限制

- 只有四个参评模型；
- 开放题每模型 30 条；
- 多个题目属于同源或 failure-mined 变体；
- Judge 与 GPT-5.5 存在同家族相关风险；
- 第二轮 adjudication 不是独立盲评；
- Hard50 严重饱和；
- MCQ 主榜接近天花板。

## 可做的结论

- 描述性排名；
- failure mode 和 option profile 分布；
- Open-ended dimension weaknesses；
- 风险门误报率；
- 诊断集饱和和分数跨度；
- 具体 bad case 的可解释归因。

## 不应做的结论

- 精确估计模型的总体材料科研能力；
- 把 1–2 题差距解释为稳定优势；
- 把模型辅助复核写成外部人类共识；
- 把单个维度小样本平均写成普遍能力定论。

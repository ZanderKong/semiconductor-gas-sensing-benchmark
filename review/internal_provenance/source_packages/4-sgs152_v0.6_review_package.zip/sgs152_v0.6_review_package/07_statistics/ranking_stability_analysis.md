
# Ranking Stability Analysis

## MCQ

主榜差距只有 4 题：

1. MiMo 119
2. Seed-2.1 118
3. GPT-5.5 117
4. DeepSeek 115

任何少量歧义题、解析差异或 Gold 问题都可能改变相邻排名。v0.6.0 保持题目和 Gold 不变，因此主榜顺序应保持不变。

## Free-response

开放题不是主榜。本轮改变了 Hard Fail 的定义和计分：

- v0.5.0：Hard Fail 只计数，不影响平均；
- v0.6.0：confirmed Hard Fail 官方分归零。

因此 v0.5.0 与 v0.6.0 的开放题平均分不能被当作同一评分口径的纵向变化。报告必须同时显示归零前 reviewed average 和归零后 official average。

## Diagnostic sets

- Robustness 有中等区分，但同源题降低独立样本量；
- Hard50 已饱和，不适合用于稳定排名；
- 禁止把 MCQ、开放题、Robustness 和 Hard50 合并为一个总分。

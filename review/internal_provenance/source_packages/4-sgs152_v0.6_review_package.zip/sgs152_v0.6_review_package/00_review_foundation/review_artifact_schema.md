
# Review Artifact Schema

## 主键

- 回答级：`task_id + model_id`
- 维度级：`task_id + model_id + dimension`
- 题目设计级：`task_id`
- MCQ 库存级：`item_id`

## 核心枚举

`review_decision`：

- `accept_with_minor_notes`
- `minor_revision`
- `major_revision`
- `confirmed_hard_fail`
- `no_answer`

`hard_fail_status`：

- `not_triggered`
- `provisional_hard_fail`
- `confirmed_hard_fail`
- `downgraded_to_dimension_issue`

`evidence_status`：

- `direct_primary_support`
- `general_authoritative_support`
- `project_rule`
- `synthetic_task_constraint`
- `primary_source_needed`
- `unresolved`

## 分数

- 每个维度：0–1.25，建议 0.05 步长；
- 八维和：0–10；
- confirmed hard fail 与 no-answer 的官方条目分为 0；
- 所有原始 Judge 分数和归零前分数必须保留。

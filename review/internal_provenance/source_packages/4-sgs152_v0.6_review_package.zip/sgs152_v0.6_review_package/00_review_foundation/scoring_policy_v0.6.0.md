
# SGS152 v0.6.0 评分政策

## MCQ

- 继续使用 exact match。
- 空输出、不可解析、多选和非法字母记错。
- 本轮不修改 Gold Answer，也不删除题目。
- 主榜仍只使用 122 道 SGS152 MCQ，保持与 v0.5.0 可比。

## Free-response

八个维度各 1.25 分：

1. `final_answer_alignment`
2. `professional_accuracy`
3. `reasoning_path`
4. `evidence_boundary`
5. `experimental_design`
6. `decision_logic`
7. `safety_and_privacy`
8. `conciseness_and_traceability`

保留三个分数概念：

- `judge_total_score`：GPT-5.6-sol 原始或已有 adjudicated 总分；
- `reviewed_dimension_total`：第二轮复核后的八维总和；
- `official_item_score`：用于 v0.6.0 官方汇总的条目分数。

计算规则：

```text
if no_answer:
    official_item_score = 0
elif confirmed_hard_fail:
    official_item_score = 0
else:
    official_item_score = reviewed_dimension_total
```

## Hard Fail

- Judge 标记先进入 `provisional_hard_fail`。
- 第二轮复核可确认、撤销或改判为普通重大缺陷。
- Hard Fail 归零不删除八维评分；归零前分数用于分析回答中仍然存在的有效内容。
- 同一回答命中多个风险门时只归零一次，但保留所有命中类别。

## 汇总

v0.6.0 同时报告：

- raw reviewed average；
- official average after hard-fail zeroing；
- confirmed hard-fail count；
- no-answer count；
- 分维度平均；
- 与 v0.5.0 口径的变化说明。

MCQ、开放题、Robustness、Hard50 不合并成一个 full-suite 总分。

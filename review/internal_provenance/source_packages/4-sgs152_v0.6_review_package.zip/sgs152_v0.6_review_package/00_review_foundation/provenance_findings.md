
# Provenance Findings

## 已确认

- 最新证据提交为 `dfa28407e5130dbc4328ac006a5368f18bdbff7d`。
- 该提交加入 `artifacts/SGS152_raw_evidence_20260713.zip`。
- ZIP 目录显示主集 MCQ、主集开放题、Robustness、Hard50、Judge、Smoke 的原始输出和 Manifest 均已归档。
- Free-response run 使用 30 题、四模型、single sampling、no retry、no manual repair；DeepSeek 有一条缺答。
- GPT-5.6-sol Judge 生成 120 条评审，运行错误为 0。
- Judge manifest 记录原始输出、Prompt、模型输出和任务集 Hash。

## 尚需本地确定性验证

当前连接器能读取 GitHub 文件和 ZIP 目录，但不能把二进制 ZIP 挂载到本地 Python 环境。因此以下工作留给 Codex：

1. 解压 ZIP；
2. 验证文件数量、非空状态和编码；
3. 从 raw model outputs 重建聚合 model_outputs；
4. 从 raw judge outputs 重建 by-item、by-dimension 和 summary；
5. 对比已提交文件的 Hash 和逐行差异；
6. 确认 `artifact_generation_working_tree_dirty=true` 没有改变结果；
7. 生成 `raw_archive_verification_manifest.json`。

在上述步骤通过前，v0.6.0 可以进入内容审核和评分设计阶段，但发布审计应保持 `provenance_replay_pending`。

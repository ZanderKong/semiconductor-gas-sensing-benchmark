
# Final Validation Specification

Codex 必须在写回后执行以下断言：

1. `data/benchmark.json` 仍为 152 题：122 MCQ、30 free-response。
2. 不得出现题目、选项或 Gold Answer 的未授权改动。
3. 120 条回答均有一个回答级记录和八个维度记录。
4. 八维分数范围 0–1.25，步长为 0.05，总和与回答级 reviewed total 一致。
5. confirmed hard fail 和 no-answer 的 official score 必须为 0。
6. 其他回答 official score 等于 reviewed total。
7. 只有三条回答属于当前确认 Hard Fail。
8. 当前 12 条误标 Hard Fail 必须改为普通维度问题。
9. 每个 override 目标必须存在，且 old/new 值可追踪。
10. 主榜 MCQ 结果不得因为开放题评分政策变化而改变。
11. 所有汇总必须从最终 by-item 文件重算，禁止手工录入平均分。
12. raw ZIP 解包后必须完成 raw-to-derived rebuild 和 Hash 比较。
13. README、dataset card、scoring protocol、risk gates、evaluation report 和 release audit 的口径必须一致。
14. 所有公开文件必须明确：这是 model-assisted project-owner adjudication，不是独立外部人类盲审。

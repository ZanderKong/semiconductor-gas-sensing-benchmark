
# Hard50 Calibration Review

Hard50 四个模型均达到 47–48 / 50，准确率 94%–96%。

## 结论

- 当前集合已经饱和；
- 不适合作为强模型的 hard diagnostic；
- 只适合记录少量 failure-mined 回归测试；
- 不进入主榜或综合总分。

## v0.6.0

保持原题和原结果，但在 README 和报告中标注：

`Hard50 is a saturated regression diagnostic, not a discriminative leaderboard.`

## v0.7 设计方向

- 多条件冲突证据；
- 表格或曲线输入；
- 量纲、对数和误差传播；
- 机理证据边界；
- 工艺与安全联合约束；
- 需要明确排除混杂的开放题；
- 避免仅靠基础知识或排除法。

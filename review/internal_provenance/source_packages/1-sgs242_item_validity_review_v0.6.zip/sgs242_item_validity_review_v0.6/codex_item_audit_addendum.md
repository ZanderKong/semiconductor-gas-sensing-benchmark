
# Codex Addendum — Item Validity Audit

## Source of truth

Use:

- `all_242_item_validity_review.csv`
- `explicit_gold_or_rationale_errors.csv`
- `item_validity_issue_queue.csv`
- `item_validity_summary.json`

## Frozen v0.6.0 rule

Do not modify:

- question text;
- options;
- Gold answers;
- Reference answers;
- item IDs;
- current model outputs.

## Required integration

1. Add the item-validity audit as a versioned review artifact.
2. Add a release note stating that all 242 items were reviewed.
3. Publish P0 and P1 counts.
4. Disclose the five P0 defects.
5. State that current Robustness and Hard50 scores include known item defects.
6. Keep current scores unchanged unless the project owner explicitly lifts the item freeze.
7. Label Hard50 as saturated and difficulty-overstated.
8. Add schema tests:
   - 242 unique item IDs;
   - 152/40/50 set counts;
   - every row has verdict, Gold status, sufficiency, source status and finding;
   - exactly five P0 records.
9. Preserve the review identity boundary.

## Future-release queue

When item edits are authorized:

1. Correct `SGS-FM-034` rationale.
2. Replace or retire `SGS-007-R03`.
3. Correct or rewrite `SGS-097-R03`.
4. Change `SGS-HARD-016` Gold to B and repair profiles.
5. Change `SGS-HARD-028` Gold to C and repair profiles.
6. Process remaining P1 items by ambiguity severity.
7. Re-score affected diagnostic sets and publish old/new diffs.


# SGS242 Item Validity Audit — Final Report

## Completion

- Reviewed: 242 / 242 unique items
- Main set: 152 / 152
- Robustness: 40 / 40
- Hard50: 50 / 50
- Validation errors: 0

## Priority distribution

- P0: 5
- P1: 49
- P2: 98
- P3: 90

## Direct scoring defects

1. `SGS-FM-034`: reference rationale contradicts the correct Gold A.
2. `SGS-007-R03`: no valid option after the new condition.
3. `SGS-097-R03`: Gold C is wrong; A remains most inappropriate.
4. `SGS-HARD-016`: Gold D is wrong; B matches the evidence and rationale.
5. `SGS-HARD-028`: Gold D is wrong; C matches the requested safe alternative and rationale.

## Release implication

The project-owner freeze keeps all item text and Gold answers unchanged for v0.6.0. Therefore:

- The audit is complete.
- Current diagnostic scores remain historically reproducible.
- Robustness and Hard50 scores contain known item-level defects.
- Public release documentation must disclose those defects.
- Any corrected score table requires explicit authorization to lift the item freeze.

## Evidence boundary

Every item has a completed validity judgment. Evidence is mapped at the topic-cluster level using project-primary files, official safety/statistics/metrology material and selected research papers. This is not a page-level systematic literature review for every subclaim.

## Reviewer identity

`model-assisted expert-style item validity audit under project-owner supervision`
